//
//  DetailViewController.swift
//  Spending Tool
//
//  Created by Beatrice Antoniu on 10/05/2021.
//  Copyright © 2021 Beatrice Antoniu. All rights reserved.
//

import UIKit
import CoreData

class DetailViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, NSFetchedResultsControllerDelegate {
    
    @IBOutlet weak var tableView: UITableView!
    let managedObjectContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    var amountSpent: Double = 0
    
    var cellsTitlesArray: Array<CGFloat> = Array()
    
    var expenseArray: Array<Double> = Array()
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if (self.category != nil)
        {
            let sectionInfo = self.fetchedResultsController.sections![section] as NSFetchedResultsSectionInfo
            print("Section info \(sectionInfo)")
            return sectionInfo.numberOfObjects
        }
        else
        {
            return 1
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        
        if (self.category != nil)
        {
            return self.fetchedResultsController.sections?.count ?? 1
            
        }
        else{return 1}
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "expenseCell", for: indexPath)
        self.configureCell(cell,indexPath: indexPath)
        return cell
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    // MARK: - Configure the cell
    
    func configureCell(_ cell: UITableViewCell, indexPath: IndexPath) {
        if (self.category != nil){
            let title = self.fetchedResultsController.fetchedObjects?[indexPath.row].amount
            cell.textLabel?.text = "£" + title!
            cell.backgroundColor = UIColor(hexString: category!.colour!, alpha: 0.2)
            if let condText = self.fetchedResultsController.fetchedObjects?[indexPath.row].notes {
                cell.detailTextLabel?.text = condText
            } else {
                cell.detailTextLabel!.text = ""
            }
            
            let progressBar = ProgressBarView(frame: CGRect(x: 670, y: 8, width: 240, height: 40))
            let expenseValue = Float.init(title!)
            let categoryValue = Float.init((category?.budget)!)
            let percentage: Float = (expenseValue!) / (categoryValue!) * 100
            progressBar.changeWidth = Int(CGFloat(percentage))
            cell.contentView.addSubview(progressBar)
            
        }
    }
    
    var category: Category?
    var expense: Expense?
    
    // MARK: - Fetched results controller
    
    var _fetchedResultsController: NSFetchedResultsController<Expense>? = nil
    
    var fetchedResultsController: NSFetchedResultsController<Expense> {
        
        
        if _fetchedResultsController != nil {
            return _fetchedResultsController!
        }
        let fetchRequest: NSFetchRequest<Expense> = Expense.fetchRequest()
        fetchRequest.fetchBatchSize = 20
        let sortDescriptor = NSSortDescriptor(key: "notes", ascending: true, selector: #selector(NSString.localizedStandardCompare(_:)))
        fetchRequest.sortDescriptors = [sortDescriptor]
        let predicate = NSPredicate(format: "hasCategory = %@", self.category!)
        fetchRequest.predicate = predicate
        let aFetchedResultsController = NSFetchedResultsController<Expense>(
            fetchRequest: fetchRequest,
            managedObjectContext: managedObjectContext,
            sectionNameKeyPath: #keyPath(Expense.category),
            cacheName: nil)
        aFetchedResultsController.delegate = self
        _fetchedResultsController = aFetchedResultsController
        
        do {
            try _fetchedResultsController!.performFetch()
        } catch {
            let nserror = error as NSError
            fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
        }
        
        return _fetchedResultsController!
        
    }
    
    
    //MARK: - Table Editing
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let context = self.fetchedResultsController.managedObjectContext
            context.delete(self.fetchedResultsController.object(at: indexPath))
            category?.expenseCounter -= 1
            
            do {
                try context.save()
            } catch {
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }
    
    func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        self.tableView.beginUpdates()
    }
    
    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        self.tableView.endUpdates()
        
    }
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange sectionInfo: NSFetchedResultsSectionInfo, atSectionIndex sectionIndex: Int, for type: NSFetchedResultsChangeType) {
        switch type {
        case .insert:
            self.tableView.insertSections(IndexSet(integer: sectionIndex), with: .fade)
        case .delete:
            self.tableView.deleteSections(IndexSet(integer: sectionIndex), with: .fade)
        default:
            return
        }
    }
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
        switch type {
        case .insert:
            tableView.insertRows(at: [newIndexPath!], with: .fade)
        case .delete:
            tableView.deleteRows(at: [indexPath!], with: .fade)
        case .update:
            self.configureCell(tableView.cellForRow(at: indexPath!)!, indexPath: newIndexPath!)
        case .move:
            tableView.moveRow(at: indexPath!, to: newIndexPath!)
        default:
            return
        }
    }
    // MARK: - Navigation
    
    override  func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let identifier = segue.identifier  {
            switch identifier
            {
            case "categoryDetail":
                let destVC = segue.destination as! CategoryDetailViewController
                if let name = self.category?.name{
                    
                    destVC.categoryName = name
                }
                
                if let notes = self.category?.notes
                {
                    destVC.categoryNotes = "Notes: " + notes
                }
                if let budget = self.category?.budget{
                    
                    destVC.categoryBuget = "Total Budget:\n" + "£" + budget
                }
                if let amount = self.category?.budget {
                    
                    let count = Int(self.category!.expenseCounter)
                    print(count)
                    if count != 0 {
                        for i in 0...(count - 1){
                            
                            let indexPath = IndexPath(row: i, section: 0)
                            
                            let fetchRequest: NSFetchRequest<Expense> = Expense.fetchRequest()
                            fetchRequest.fetchBatchSize = 20
                            //add a sort descriptor
                            let sortDescriptor = NSSortDescriptor(key: "amount", ascending: false, selector: #selector(NSString.localizedStandardCompare(_:)))
                            //add the sort
                            fetchRequest.sortDescriptors = [sortDescriptor]
                            
                            //add the predicate on the selected category
                            let predicate = NSPredicate(format: "hasCategory = %@", self.category!)
                            fetchRequest.predicate = predicate
                            //create a fetch controller
                            let aFetchedResultsController = NSFetchedResultsController<Expense>(
                                fetchRequest: fetchRequest,
                                managedObjectContext: managedObjectContext,
                                sectionNameKeyPath: #keyPath(Expense.category),
                                cacheName: nil) //note must change the cache name to nil to prevent cacheing
                            aFetchedResultsController.delegate = self
                            _fetchedResultsController = aFetchedResultsController
                            do {
                                try _fetchedResultsController!.performFetch()
                                
                            } catch {
                                let nserror = error as NSError
                                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
                            }
                            
                            let title = _fetchedResultsController?.fetchedObjects?[indexPath.row].amount
                            expenseArray.append(Double.init(title!)!)
                            
                            
                            let value = CGFloat.init(Float.init(title!)!)
                            cellsTitlesArray.append(value)
                        }
                        for expense in expenseArray {
                            amountSpent += expense
                        }
                        for _ in cellsTitlesArray {
                            if(count >= 4) {
                                var lastPosition = amountSpent
                                lastPosition = Double(cellsTitlesArray[0] - cellsTitlesArray[1] - cellsTitlesArray[2] - cellsTitlesArray[3]) - amountSpent
                                cellsTitlesArray.insert(CGFloat(lastPosition), at: 4)
                            }
                        }
                        
                        print(expenseArray)
                        destVC.categoryAmountSpent = "Amount Spend: £\(String(format: "%.2f", (amount)))"
                        destVC.expensesArray = cellsTitlesArray
                        destVC.totalBudget = CGFloat.init(Float.init((category?.budget!)!)!)
                    }
                }
                if let amountRemaining = self.category?.budget
                {
                    destVC.categoryBuget = "Total Budget: \n£\(amountRemaining)"
                    destVC.categoryAmountSpent = "Amount Spent: \n£\(String(format: "%.2f", (self.amountSpent)))"
                    let budgetRemaining = ((Double(amountRemaining)!) - self.amountSpent)
                    destVC.categoryAmountRemaining = "Amount Remaining: £\(String(format: "%.2f", (budgetRemaining)))"
                }
                
            case "addExpense":
                if let category = self.category
                {
                    let destVC = segue.destination as! AddExpenseViewController
                    destVC.category = category
                }
                
            default:
                break
            }
        }
    }
    
    @IBAction func editExpense(sender: UIBarButtonItem) {
        if !tableView.isEditing {
            tableView.isEditing = true
        } else if tableView.isEditing {
            tableView.isEditing = false
        }
    }
}

