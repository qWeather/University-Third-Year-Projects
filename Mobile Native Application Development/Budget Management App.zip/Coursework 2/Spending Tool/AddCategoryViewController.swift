//
//  AddCategoryViewController.swift
//  Spending Tool
//
//  Created by Beatrice Antoniu on 10/05/2021.
//  Copyright © 2021 Beatrice Antoniu. All rights reserved.
//

import UIKit

class AddCategoryViewController: UIViewController, UIColorPickerViewControllerDelegate {
    
    @IBOutlet weak var categoryNameTextField: UITextField!
    @IBOutlet weak var categoryBudgetTextField: UITextField!
    @IBOutlet weak var categoryNotesTextField: UITextField!
    @IBOutlet weak var colourPicked: UIView!
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func selectColour() {
        let colourPicker = UIColorPickerViewController()
        colourPicker.delegate = self
        colourPicker.isModalInPresentation = true
        present(colourPicker, animated: true)
    }
    
    func colorPickerViewControllerDidFinish(_ viewController: UIColorPickerViewController)
    {
        let colour = viewController.selectedColor
        colourPicked.backgroundColor = colour
    }
    
    func colorPickerViewControllerDidSelectColor(_ viewController: UIColorPickerViewController)
    {
        let colour = viewController.selectedColor
        colourPicked.backgroundColor = colour
    }
    
    @IBAction func saveCategory(_ sender: UIButton) {
        
        //new managed object
        
        let newCategory = Category(context: context)
        if self.categoryNameTextField.text != "" && colourPicked.backgroundColor != UIColor(hexString: "")
        {
            newCategory.name = self.categoryNameTextField.text
            newCategory.budget = self.categoryBudgetTextField.text
            newCategory.notes = self.categoryNotesTextField.text
            newCategory.colour = self.colourPicked.backgroundColor?.toHexString()
            newCategory.visits = 0
            //save
            (UIApplication.shared.delegate as! AppDelegate).saveContext()
        } else {
            _ = UIAlertController(title: "No category name!", message: "Category not added.", preferredStyle: .alert)
        }
    }
}
