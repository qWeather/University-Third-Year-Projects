//
//  ProgressBarView.swift
//  Spending Tool
//
//  Created by Beatrice Antoniu on 15/05/2021.
//  Copyright © 2021 Beatrice Antoniu. All rights reserved.
//

import UIKit

class ProgressBarView: UIView {
    
    var changeWidth = 0
    
    override func draw(_ rect:CGRect) {
        
        let newWidth = rect.width / 100.0 * CGFloat(changeWidth)
        
        let barPath = UIBezierPath(rect: CGRect(origin: .zero, size: CGSize(width: rect.width, height: rect.height)))
        
        let backgroundMask = CAShapeLayer()
        backgroundMask.path = UIBezierPath(roundedRect: rect, cornerRadius: rect.height * 0.25).cgPath
        layer.mask = backgroundMask
        
        let layerPath = UIBezierPath(rect: CGRect(origin: .zero, size: CGSize(width: newWidth, height: rect.height)))

        UIColor(hexString: "32a8a8").setFill()
        barPath.fill()
        
        UIColor(hexString: "4debeb").setFill()
        UIColor(hexString: "32a8a8").setStroke()
        layerPath.fill()
        layerPath.lineWidth = 3
        layerPath.stroke()
    }
}
