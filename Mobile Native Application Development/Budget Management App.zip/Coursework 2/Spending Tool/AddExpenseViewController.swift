//
//  AddExpenseViewController.swift
//  Spending Tool
//
//  Created by Beatrice Antoniu on 10/05/2021.
//  Copyright © 2021 Beatrice Antoniu. All rights reserved.
//

import EventKit
import UIKit
import CoreData

class AddExpenseViewController: UIViewController {
    
    @IBOutlet weak var expenseNameLabel: UILabel!
    @IBOutlet weak var expenseAmountTextField: UITextField!
    @IBOutlet weak var expeneseNotesTextField: UITextField!
    @IBOutlet weak var expenseSetReminder: UISwitch!
    @IBOutlet weak var expenseSetDateAndTime: UIDatePicker!
    @IBOutlet weak var expenseSetOccurence: UISegmentedControl!
    
    var eventStore = EKEventStore()
    //var rule = EKRecurrenceRule()
    
    var category:Category?
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.expenseNameLabel.text = self.category?.name
    }
    
    @IBAction func saveExpense(_ sender: UIButton) {
        let expense = Expense(context: context)
        
        expense.amount = self.expenseAmountTextField.text
        expense.notes = self.expeneseNotesTextField.text
        expense.date = self.expenseSetDateAndTime.date
        
        if(expenseSetReminder.isOn && expenseSetDateAndTime.date > Date()) {
            expense.reminder = true
            
            eventStore.requestAccess(to: EKEntityType.reminder, completion: {
                granted, error in
                if (granted) && (error == nil) {
                    print("granted \(granted)")
                    
                    let reminder:EKReminder = EKReminder(eventStore: self.eventStore)
                    reminder.title = (expense.hasCategory?.name)! + " To pay: £" + expense.amount!
                    reminder.priority = 2
                    
                    reminder.notes = expense.notes
                    
                    let dueDate = self.expenseSetDateAndTime.date
                    reminder.dueDateComponents = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute], from: dueDate)
                    let alarmTime = self.expenseSetDateAndTime.date.addingTimeInterval(TimeInterval (60*60))
                    let alarm = EKAlarm(absoluteDate: alarmTime)
                    reminder.addAlarm(alarm)
                    
                    if(self.expenseSetOccurence.selectedSegmentIndex == 0) {
                        expense.occurence = "One-off"
                    } else if(self.expenseSetOccurence.selectedSegmentIndex == 1) {
                        expense.occurence = "Daily"
                        let rule = EKRecurrenceRule(recurrenceWith: .daily, interval: 1, end: nil)
                        reminder.addRecurrenceRule(rule)
                    } else if(self.expenseSetOccurence.selectedSegmentIndex == 2) {
                        expense.occurence = "Weekly"
                        let rule = EKRecurrenceRule(recurrenceWith: .weekly, interval: 1, end: nil)
                        reminder.addRecurrenceRule(rule)
                    } else if(self.expenseSetOccurence.selectedSegmentIndex == 3) {
                        expense.occurence = "Monthly"
                        let rule = EKRecurrenceRule(recurrenceWith: .monthly, interval: 1, end: nil)
                        reminder.addRecurrenceRule(rule)
                    }
                    
                    reminder.calendar = self.eventStore.defaultCalendarForNewReminders()
                    
                    do {
                        try self.eventStore.save(reminder, commit: true)
                    } catch {
                        print("Couldn't save reminder")
                        return
                    }
                    print("Saved to Reminders")
                }
                
            })
            
            eventStore.requestAccess(to: .event) {
                granted, error in
                if (granted) && (error == nil) {
                    print("granted \(granted)")
                    
                    let event:EKEvent = EKEvent(eventStore: self.eventStore)
                    event.title = "In: " + (expense.hasCategory?.name)! + " to pay: £" + expense.amount!
                    event.startDate = self.expenseSetDateAndTime.date
                    event.endDate = self.expenseSetDateAndTime.date.addingTimeInterval(TimeInterval (60*60))
                    event.notes = expense.notes
                    event.calendar = self.eventStore.defaultCalendarForNewEvents
                    do{
                        try self.eventStore.save(event, span: .thisEvent)
                    } catch {
                        print("Couldn't save event")
                    }
                    print("Saved to Calendar")
                } else {
                    print("Couldn't save event")
                }
            }
        } else {
            expense.reminder = false
        }
        
        category?.expenseCounter += 1
        
        category?.addToExpenses(expense)
        
        (UIApplication.shared.delegate as! AppDelegate).saveContext()
    }
    
    /*@IBAction func repeatReminder(_ sender: Any) {
     switch self.expenseSetOccurence.selectedSegmentIndex {
     case 1:
     self.rule = EKRecurrenceRule(recurrenceWith: EKRecurrenceFrequency.daily, interval: 1, end: nil)
     break
     case 2:
     self.rule = EKRecurrenceRule(recurrenceWith: EKRecurrenceFrequency.weekly, interval: 1, end: nil)
     break
     case 3:
     self.rule = EKRecurrenceRule(recurrenceWith: EKRecurrenceFrequency.monthly, interval: 1, end: nil)
     break
     default:
     break
     }
     }*/
}

