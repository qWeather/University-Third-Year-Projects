//
//  PieChartView.swift
//  Spending Tool
//
//  Created by Beatrice Antoniu on 15/05/2021.
//  Copyright © 2021 Beatrice Antoniu. All rights reserved.
//

import UIKit

class PieChartView: UIView {
    
    var data: [CGFloat] = Array()
    
    var totalBudget = CGFloat()
    
    override func draw(_ rect: CGRect) {
        
        let center: CGPoint = CGPoint(x: rect.midX, y: rect.midY)
        
        let radius = min(rect.width, rect.height) / 2.0
        
        var startAngle: CGFloat = 0.0
        var count = 0
        for value in data {
            
            if(count < 4) {
                
                let endAngle = CGFloat(value) / totalBudget * CGFloat.pi * 2.0 + startAngle
                
                let circlePath = UIBezierPath(arcCenter: center, radius: radius, startAngle: startAngle, endAngle: endAngle, clockwise: true)
                
                circlePath.addLine(to: center)
                
                UIColor(red: (CGFloat(arc4random_uniform(256)) / 255.0), green: (CGFloat(arc4random_uniform(256)) / 255.0), blue: (CGFloat(arc4random_uniform(256)) / 255.0), alpha: 1.0).setFill()
                
                circlePath.fill()
                
                startAngle = endAngle
                count += 1
            } else if(count == 4) {
                
                let lastPosition = value
                let endAngle = CGFloat(value) / (totalBudget - lastPosition) * CGFloat.pi * 2.0 + startAngle
                
                let circlePath = UIBezierPath(arcCenter: center, radius: radius, startAngle: startAngle, endAngle: endAngle, clockwise: true)
                
                circlePath.addLine(to: center)
                
                UIColor(red: (CGFloat(arc4random_uniform(256)) / 255.0), green: (CGFloat(arc4random_uniform(256)) / 255.0), blue: (CGFloat(arc4random_uniform(256)) / 255.0), alpha: 1.0).setFill()
                
                circlePath.fill()
                
                startAngle = endAngle
                count += 1
            }
              
        }
    }
    
}
