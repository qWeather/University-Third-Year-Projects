//
//  CategoryDetailViewController.swift
//  Spending Tool
//
//  Created by Beatrice Antoniu on 10/05/2021.
//  Copyright © 2021 Beatrice Antoniu. All rights reserved.
//

import UIKit

class CategoryDetailViewController: UIViewController {
    
    @IBOutlet weak var categoryDetailNameLabel: UILabel!
    @IBOutlet weak var categoryDetailNotesTextView: UITextView!
    @IBOutlet weak var categoryDetailTotalBudget: UILabel!
    @IBOutlet weak var categoryDetailAmountSpent: UILabel!
    @IBOutlet weak var categoryDetailAmountRemaining: UILabel!
    
    var categoryName = ""
    var categoryNotes = ""
    var categoryBuget = ""
    var categoryAmountSpent = ""
    var categoryAmountRemaining = ""
    
    var expensesArray: [CGFloat] = Array()
    var totalBudget = CGFloat()
    
    var category:Category?
    var expense:Expense?
    override func viewDidLoad() {
        super.viewDidLoad()
        categoryDetailNameLabel.text = categoryName
        categoryDetailNotesTextView.text = categoryNotes
        categoryDetailTotalBudget.text = categoryBuget
        categoryDetailAmountSpent.text = categoryAmountSpent
        categoryDetailAmountRemaining.text = categoryAmountRemaining
        
        //Pie Chart
        let pieChart = PieChartView(frame: CGRect(x: 370, y: 162, width: 240, height: 254))
        pieChart.backgroundColor = UIColor.white
        pieChart.data = expensesArray
        pieChart.totalBudget = totalBudget
        view.addSubview(pieChart)
        print(expensesArray)
        
    }
}
