//
//  ViewController.swift
//  Unit Converter
//
//  Created by Beatrice Antoniu on 07/02/2021.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var historyLabel: UILabel!
    @IBOutlet weak var historyLabel2: UILabel!
    @IBOutlet weak var historyLabel3: UILabel!
    @IBOutlet weak var historyLabel4: UILabel!
    @IBOutlet weak var historyLabel5: UILabel!
    
    let defaults = UserDefaults.standard
    
    func setDefaults() {
        defaults.set(speedDictionary, forKey: "speed")
        defaults.set(lengthDictionary, forKey: "length")
        defaults.set(volumeDictionary, forKey: "volume")
        defaults.set(temperatureDictionary, forKey: "temperature")
        defaults.set(weightDictionary, forKey: "weight")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        _ = defaults.object(forKey: "speed") as? [Int: String] ?? [Int: String]()
        _ = defaults.object(forKey: "length") as? [Int: String] ?? [Int: String]()
        _ = defaults.object(forKey: "volume") as? [Int: String] ?? [Int: String]()
        _ = defaults.object(forKey: "temperature") as? [Int: String] ?? [Int: String]()
        _ = defaults.object(forKey: "weight") as? [Int: String] ?? [Int: String]()
    }
    
    @IBAction func weightHistory(_ sender: Any) {
        for (key, _) in weightDictionary.enumerated() {
            if(weightDictionary.count == 1) {
                historyLabel.text = "Kilogram: " + String(weightDictionary[key].kilogram) + " Gram: " + String(weightDictionary[key].gram) + " Ounce: " + String(weightDictionary[key].ounce) + " Pound: " + String(weightDictionary[key].pound) + " Stone-pound: " + String(weightDictionary[key].stonePound)
            } else if(weightDictionary.count == 2) {
                historyLabel2.text = "Kilogram: " + String(weightDictionary[key].kilogram) + " Gram: " + String(weightDictionary[key].gram) + " Ounce: " + String(weightDictionary[key].ounce) + " Pound: " + String(weightDictionary[key].pound) + " Stone-pound: " + String(weightDictionary[key].stonePound)
            } else if(weightDictionary.count == 3) {
                historyLabel3.text = "Kilogram: " + String(weightDictionary[key].kilogram) + " Gram: " + String(weightDictionary[key].gram) + " Ounce: " + String(weightDictionary[key].ounce) + " Pound: " + String(weightDictionary[key].pound) + " Stone-pound: " + String(weightDictionary[key].stonePound)
            } else if(weightDictionary.count == 4) {
                historyLabel4.text = "Kilogram: " + String(weightDictionary[key].kilogram) + " Gram: " + String(weightDictionary[key].gram) + " Ounce: " + String(weightDictionary[key].ounce) + " Pound: " + String(weightDictionary[key].pound) + " Stone-pound: " + String(weightDictionary[key].stonePound)
            } else if(weightDictionary.count == 5) {
                historyLabel5.text = "Kilogram: " + String(weightDictionary[key].kilogram) + " Gram: " + String(weightDictionary[key].gram) + " Ounce: " + String(weightDictionary[key].ounce) + " Pound: " + String(weightDictionary[key].pound) + " Stone-pound: " + String(weightDictionary[key].stonePound)
            } else if(weightDictionary.count > 5) {
                weightDictionary.removeFirst()
                historyLabel.text = "Kilogram: " + String(weightDictionary[key-1].kilogram) + " Gram: " + String(weightDictionary[key-1].gram) + " Ounce: " + String(weightDictionary[key-1].ounce) + " Pound: " + String(weightDictionary[key-1].pound) + " Stone-pound: " + String(weightDictionary[key-1].stonePound)
                historyLabel2.text = "Kilogram: " + String(weightDictionary[key-1].kilogram) + " Gram: " + String(weightDictionary[key-1].gram) + " Ounce: " + String(weightDictionary[key-1].ounce) + " Pound: " + String(weightDictionary[key-1].pound) + " Stone-pound: " + String(weightDictionary[key-1].stonePound)
                historyLabel3.text = "Kilogram: " + String(weightDictionary[key-1].kilogram) + " Gram: " + String(weightDictionary[key-1].gram) + " Ounce: " + String(weightDictionary[key-1].ounce) + " Pound: " + String(weightDictionary[key-1].pound) + " Stone-pound: " + String(weightDictionary[key-1].stonePound)
                historyLabel4.text = "Kilogram: " + String(weightDictionary[key-1].kilogram) + " Gram: " + String(weightDictionary[key-1].gram) + " Ounce: " + String(weightDictionary[key-1].ounce) + " Pound: " + String(weightDictionary[key-1].pound) + " Stone-pound: " + String(weightDictionary[key-1].stonePound)
                historyLabel5.text = "Kilogram: " + String(weightDictionary[key-1].kilogram) + " Gram: " + String(weightDictionary[key-1].gram) + " Ounce: " + String(weightDictionary[key-1].ounce) + " Pound: " + String(weightDictionary[key-1].pound) + " Stone-pound: " + String(weightDictionary[key-1].stonePound)
            } else {
                historyLabel.text = "Kilogram: Grams: Ounce: Pound: Stone-pound: "
                historyLabel2.text = "Kilogram: Grams: Ounce: Pound: Stone-pound: "
                historyLabel3.text = "Kilogram: Grams: Ounce: Pound: Stone-pound: "
                historyLabel4.text = "Kilogram: Grams: Ounce: Pound: Stone-pound: "
                historyLabel5.text = "Kilogram: Grams: Ounce: Pound: Stone-pound: "
            }
        }
    }
    @IBAction func temperatureHistory(_ sender: Any) {
        for (key, _) in temperatureDictionary.enumerated() {
            if(temperatureDictionary.count == 1) {
                historyLabel.text = " Celsius: " + String(temperatureDictionary[key].celsius) + " Fahrenheit: " + String(temperatureDictionary[key].fahrenheit) + " Kelvin: " + String(temperatureDictionary[key].kelvin)
            } else if(temperatureDictionary.count == 2) {
                historyLabel2.text = " Celsius: " + String(temperatureDictionary[key].celsius) + " Fahrenheit: " + String(temperatureDictionary[key].fahrenheit) + " Kelvin: " + String(temperatureDictionary[key].kelvin)
            } else if(temperatureDictionary.count == 3) {
                historyLabel3.text = " Celsius: " + String(temperatureDictionary[key].celsius) + " Fahrenheit: " + String(temperatureDictionary[key].fahrenheit) + " Kelvin: " + String(temperatureDictionary[key].kelvin)
            } else if(temperatureDictionary.count == 4) {
                historyLabel4.text = " Celsius: " + String(temperatureDictionary[key].celsius) + " Fahrenheit: " + String(temperatureDictionary[key].fahrenheit) + " Kelvin: " + String(temperatureDictionary[key].kelvin)
            } else if(temperatureDictionary.count == 5) {
                historyLabel5.text = " Celsius: " + String(temperatureDictionary[key].celsius) + " Fahrenheit: " + String(temperatureDictionary[key].fahrenheit) + " Kelvin: " + String(temperatureDictionary[key].kelvin)
            } else if(temperatureDictionary.count > 5) {
                temperatureDictionary.removeFirst()
                historyLabel.text = " Celsius: " + String(temperatureDictionary[key-1].celsius) + " Fahrenheit: " + String(temperatureDictionary[key-1].fahrenheit) + " Kelvin: " + String(temperatureDictionary[key-1].kelvin)
                historyLabel2.text = " Celsius: " + String(temperatureDictionary[key-1].celsius) + " Fahrenheit: " + String(temperatureDictionary[key-1].fahrenheit) + " Kelvin: " + String(temperatureDictionary[key-1].kelvin)
                historyLabel3.text = " Celsius: " + String(temperatureDictionary[key-1].celsius) + " Fahrenheit: " + String(temperatureDictionary[key-1].fahrenheit) + " Kelvin: " + String(temperatureDictionary[key-1].kelvin)
                historyLabel4.text = " Celsius: " + String(temperatureDictionary[key-1].celsius) + " Fahrenheit: " + String(temperatureDictionary[key-1].fahrenheit) + " Kelvin: " + String(temperatureDictionary[key-1].kelvin)
                historyLabel5.text = " Celsius: " + String(temperatureDictionary[key-1].celsius) + " Fahrenheit: " + String(temperatureDictionary[key-1].fahrenheit) + " Kelvin: " + String(temperatureDictionary[key-1].kelvin)
            } else {
                historyLabel.text = "Celsius: Fahrenheit: Kelvin: "
                historyLabel2.text = "Celsius: Fahrenheit: Kelvin: "
                historyLabel3.text = "Celsius: Fahrenheit: Kelvin: "
                historyLabel4.text = "Celsius: Fahrenheit: Kelvin: "
                historyLabel5.text = "Celsius: Fahrenheit: Kelvin: "
            }
        }
    }
    @IBAction func lengthHistory(_ sender: Any) {
        for (key, _) in lengthDictionary.enumerated() {
            if(lengthDictionary.count == 1) {
                historyLabel.text = "Metre: " + String(lengthDictionary[key].metre) + " Km: " + String(lengthDictionary[key].km) + " Cm: " + String(lengthDictionary[key].mile)
                historyLabel.text! += String(lengthDictionary[key].cm) + " Mm: " + String(lengthDictionary[key].mm) + " Yard: " + String(lengthDictionary[key].yard) + " Inch: " + String(lengthDictionary[key].inch)
            } else if(lengthDictionary.count == 2) {
                historyLabel2.text = "Metre: " + String(lengthDictionary[key].metre) + " Km: " + String(lengthDictionary[key].km) + " Cm: " + String(lengthDictionary[key].mile)
                historyLabel2.text! += String(lengthDictionary[key].cm) + " Mm: " + String(lengthDictionary[key].mm) + " Yard: " + String(lengthDictionary[key].yard) + " Inch: " + String(lengthDictionary[key].inch)
            } else if(lengthDictionary.count == 3) {
                historyLabel3.text = "Metre: " + String(lengthDictionary[key].metre) + " Km: " + String(lengthDictionary[key].km) + " Cm: " + String(lengthDictionary[key].mile)
                historyLabel3.text! += String(lengthDictionary[key].cm) + " Mm: " + String(lengthDictionary[key].mm) + " Yard: " + String(lengthDictionary[key].yard) + " Inch: " + String(lengthDictionary[key].inch)
            } else if(lengthDictionary.count == 4) {
                historyLabel4.text = "Metre: " + String(lengthDictionary[key].metre) + " Km: " + String(lengthDictionary[key].km) + " Cm: " + String(lengthDictionary[key].mile)
                historyLabel4.text! += String(lengthDictionary[key].cm) + " Mm: " + String(lengthDictionary[key].mm) + " Yard: " + String(lengthDictionary[key].yard) + " Inch: " + String(lengthDictionary[key].inch)
            } else if(lengthDictionary.count == 5) {
                historyLabel5.text = "Metre: " + String(lengthDictionary[key].metre) + " Km: " + String(lengthDictionary[key].km) + " Cm: " + String(lengthDictionary[key].mile)
                historyLabel5.text! += String(lengthDictionary[key].cm) + " Mm: " + String(lengthDictionary[key].mm) + " Yard: " + String(lengthDictionary[key].yard) + " Inch: " + String(lengthDictionary[key].inch)
            } else if(lengthDictionary.count > 5) {
                lengthDictionary.removeFirst()
                historyLabel.text = "Metre: " + String(lengthDictionary[key-1].metre) + " Km: " + String(lengthDictionary[key-1].km) + " Cm: " + String(lengthDictionary[key-1].mile)
                historyLabel.text! += String(lengthDictionary[key-1].cm) + " Mm: " + String(lengthDictionary[key-1].mm) + " Yard: " + String(lengthDictionary[key-1].yard) + " Inch: " + String(lengthDictionary[key-1].inch)
                historyLabel2.text = "Metre: " + String(lengthDictionary[key-1].metre) + " Km: " + String(lengthDictionary[key-1].km) + " Cm: " + String(lengthDictionary[key-1].mile)
                historyLabel2.text! += String(lengthDictionary[key-1].cm) + " Mm: " + String(lengthDictionary[key-1].mm) + " Yard: " + String(lengthDictionary[key-1].yard) + " Inch: " + String(lengthDictionary[key-1].inch)
                historyLabel3.text = "Metre: " + String(lengthDictionary[key-1].metre) + " Km: " + String(lengthDictionary[key-1].km) + " Cm: " + String(lengthDictionary[key-1].mile)
                historyLabel3.text! += String(lengthDictionary[key-1].cm) + " Mm: " + String(lengthDictionary[key-1].mm) + " Yard: " + String(lengthDictionary[key-1].yard) + " Inch: " + String(lengthDictionary[key-1].inch)
                historyLabel4.text = "Metre: " + String(lengthDictionary[key-1].metre) + " Km: " + String(lengthDictionary[key-1].km) + " Cm: " + String(lengthDictionary[key-1].mile)
                historyLabel4.text! += String(lengthDictionary[key-1].cm) + " Mm: " + String(lengthDictionary[key-1].mm) + " Yard: " + String(lengthDictionary[key-1].yard) + " Inch: " + String(lengthDictionary[key-1].inch)
                historyLabel5.text = "Metre: " + String(lengthDictionary[key-1].metre) + " Km: " + String(lengthDictionary[key-1].km) + " Cm: " + String(lengthDictionary[key-1].mile)
                historyLabel5.text! += String(lengthDictionary[key-1].cm) + " Mm: " + String(lengthDictionary[key-1].mm) + " Yard: " + String(lengthDictionary[key-1].yard) + " Inch: " + String(lengthDictionary[key-1].inch)
            } else {
                historyLabel.text = "Metre: Km: Mile: Cm: Mm: Yard: Inch: "
                historyLabel2.text = "Metre: Km: Mile: Cm: Mm: Yard: Inch: "
                historyLabel3.text = "Metre: Km: Mile: Cm: Mm: Yard: Inch: "
                historyLabel4.text = "Metre: Km: Mile: Cm: Mm: Yard: Inch: "
                historyLabel5.text = "Metre: Km: Mile: Cm: Mm: Yard: Inch: "
            }
        }
    }
    @IBAction func speedHistory(_ sender: Any) {
        for (key, _) in speedDictionary.enumerated() {
            if(speedDictionary.count == 1) {
                historyLabel.text = "Metres/sec: " + String(speedDictionary[key].ms) + " Km/hour: " + String(speedDictionary[key].kmh) + " Miles/hour: " + String(speedDictionary[key].mh) + " Knot: " + String(speedDictionary[key].knot)
            } else if(speedDictionary.count == 2) {
                historyLabel2.text = "Metres/sec: " + String(speedDictionary[key].ms) + " Km/hour: " + String(speedDictionary[key].kmh) + " Miles/hour: " + String(speedDictionary[key].mh) + " Knot: " + String(speedDictionary[key].knot)
            } else if(speedDictionary.count == 3) {
                historyLabel3.text = "Metres/sec: " + String(speedDictionary[key].ms) + " Km/hour: " + String(speedDictionary[key].kmh) + " Miles/hour: " + String(speedDictionary[key].mh) + " Knot: " + String(speedDictionary[key].knot)
            } else if(speedDictionary.count == 4) {
                historyLabel4.text = "Metres/sec: " + String(speedDictionary[key].ms) + " Km/hour: " + String(speedDictionary[key].kmh) + " Miles/hour: " + String(speedDictionary[key].mh) + " Knot: " + String(speedDictionary[key].knot)
            } else if(speedDictionary.count == 5) {
                historyLabel5.text = "Metres/sec: " + String(speedDictionary[key].ms) + " Km/hour: " + String(speedDictionary[key].kmh) + " Miles/hour: " + String(speedDictionary[key].mh) + " Knot: " + String(speedDictionary[key].knot)
            } else if(speedDictionary.count > 5) {
                speedDictionary.removeFirst()
                historyLabel.text = "Metres/sec: " + String(speedDictionary[key-1].ms) + " Km/hour: " + String(speedDictionary[key-1].kmh) + " Miles/hour: " + String(speedDictionary[key-1].mh) + " Knot: " + String(speedDictionary[key-1].knot)
                historyLabel2.text = "Metres/sec: " + String(speedDictionary[key-1].ms) + " Km/hour: " + String(speedDictionary[key-1].kmh) + " Miles/hour: " + String(speedDictionary[key-1].mh) + " Knot: " + String(speedDictionary[key-1].knot)
                historyLabel3.text = "Metres/sec: " + String(speedDictionary[key-1].ms) + " Km/hour: " + String(speedDictionary[key-1].kmh) + " Miles/hour: " + String(speedDictionary[key-1].mh) + " Knot: " + String(speedDictionary[key-1].knot)
                historyLabel4.text = "Metres/sec: " + String(speedDictionary[key-1].ms) + " Km/hour: " + String(speedDictionary[key-1].kmh) + " Miles/hour: " + String(speedDictionary[key-1].mh) + " Knot: " + String(speedDictionary[key-1].knot)
                historyLabel5.text = "Metres/sec: " + String(speedDictionary[key-1].ms) + " Km/hour: " + String(speedDictionary[key-1].kmh) + " Miles/hour: " + String(speedDictionary[key-1].mh) + " Knot: " + String(speedDictionary[key-1].knot)
            } else {
                historyLabel.text = "Metres/sec: Km/hour: Miles/hour: Knot: "
                historyLabel2.text = "Metres/sec: Km/hour: Miles/hour: Knot: "
                historyLabel3.text = "Metres/sec: Km/hour: Miles/hour: Knot: "
                historyLabel4.text = "Metres/sec: Km/hour: Miles/hour: Knot: "
                historyLabel5.text = "Metres/sec: Km/hour: Miles/hour: Knot: "
            }
        }
    }
    @IBAction func volumeHistory(_ sender: Any) {
        for (key, _) in volumeDictionary.enumerated() {
            if(volumeDictionary.count == 1) {
                historyLabel.text = "UK Gallon: " + String(volumeDictionary[key].ukGallon) + " Litre: " + String(volumeDictionary[key].litre) + " UK Pint: " + String(volumeDictionary[key].ukPint) + " Fluid ounce: " + String(volumeDictionary[key].fluidOunce) + " Millilitre: " + String(volumeDictionary[key].millilitre)
            } else if(volumeDictionary.count == 2) {
                historyLabel2.text = "UK Gallon: " + String(volumeDictionary[key].ukGallon) + " Litre: " + String(volumeDictionary[key].litre) + " UK Pint: " + String(volumeDictionary[key].ukPint) + " Fluid ounce: " + String(volumeDictionary[key].fluidOunce) + " Millilitre: " + String(volumeDictionary[key].millilitre)
            } else if(volumeDictionary.count == 3) {
                historyLabel3.text = "UK Gallon: " + String(volumeDictionary[key].ukGallon) + " Litre: " + String(volumeDictionary[key].litre) + " UK Pint: " + String(volumeDictionary[key].ukPint) + " Fluid ounce: " + String(volumeDictionary[key].fluidOunce) + " Millilitre: " + String(volumeDictionary[key].millilitre)
            } else if(volumeDictionary.count == 4) {
                historyLabel4.text = "UK Gallon: " + String(volumeDictionary[key].ukGallon) + " Litre: " + String(volumeDictionary[key].litre) + " UK Pint: " + String(volumeDictionary[key].ukPint) + " Fluid ounce: " + String(volumeDictionary[key].fluidOunce) + " Millilitre: " + String(volumeDictionary[key].millilitre)
            } else if(volumeDictionary.count == 5) {
                historyLabel5.text = "UK Gallon: " + String(volumeDictionary[key].ukGallon) + " Litre: " + String(volumeDictionary[key].litre) + " UK Pint: " + String(volumeDictionary[key].ukPint) + " Fluid ounce: " + String(volumeDictionary[key].fluidOunce) + " Millilitre: " + String(volumeDictionary[key].millilitre)
            } else if(volumeDictionary.count > 5) {
                volumeDictionary.removeFirst()
                historyLabel.text = "UK Gallon: " + String(volumeDictionary[key-1].ukGallon) + " Litre: " + String(volumeDictionary[key-1].litre) + " UK Pint: " + String(volumeDictionary[key-1].ukPint) + " Fluid ounce: " + String(volumeDictionary[key-1].fluidOunce) + " Millilitre: " + String(volumeDictionary[key-1].millilitre)
                historyLabel2.text = "UK Gallon: " + String(volumeDictionary[key-1].ukGallon) + " Litre: " + String(volumeDictionary[key-1].litre) + " UK Pint: " + String(volumeDictionary[key-1].ukPint) + " Fluid ounce: " + String(volumeDictionary[key-1].fluidOunce) + " Millilitre: " + String(volumeDictionary[key-1].millilitre)
                historyLabel3.text = "UK Gallon: " + String(volumeDictionary[key-1].ukGallon) + " Litre: " + String(volumeDictionary[key-1].litre) + " UK Pint: " + String(volumeDictionary[key-1].ukPint) + " Fluid ounce: " + String(volumeDictionary[key-1].fluidOunce) + " Millilitre: " + String(volumeDictionary[key-1].millilitre)
                historyLabel4.text = "UK Gallon: " + String(volumeDictionary[key-1].ukGallon) + " Litre: " + String(volumeDictionary[key-1].litre) + " UK Pint: " + String(volumeDictionary[key-1].ukPint) + " Fluid ounce: " + String(volumeDictionary[key-1].fluidOunce) + " Millilitre: " + String(volumeDictionary[key-1].millilitre)
                historyLabel5.text = "UK Gallon: " + String(volumeDictionary[key-1].ukGallon) + " Litre: " + String(volumeDictionary[key-1].litre) + " UK Pint: " + String(volumeDictionary[key-1].ukPint) + " Fluid ounce: " + String(volumeDictionary[key-1].fluidOunce) + " Millilitre: " + String(volumeDictionary[key-1].millilitre)
            } else {
                historyLabel.text = "UK Gallon: Litre: UK Pint: Flui ounce: Millilitre: "
                historyLabel2.text = "UK Gallon: Litre: UK Pint: Flui ounce: Millilitre: "
                historyLabel3.text = "UK Gallon: Litre: UK Pint: Flui ounce: Millilitre: "
                historyLabel4.text = "UK Gallon: Litre: UK Pint: Flui ounce: Millilitre: "
                historyLabel5.text = "UK Gallon: Litre: UK Pint: Flui ounce: Millilitre: "
            }
        }
        
    }
    
    @IBAction func changeToTwoDecimals(_ sender: Any) {
    }
    
    @IBAction func changeToFourDecimals(_ sender: Any) {
    }
    
}

