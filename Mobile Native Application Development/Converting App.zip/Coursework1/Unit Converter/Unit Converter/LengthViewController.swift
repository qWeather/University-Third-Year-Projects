//
//  LengthViewController.swift
//  Unit Converter
//
//  Created by Beatrice Antoniu on 15/03/2021.
//

import UIKit
class LengthViewController:UIViewController {
    
    //textfields of Length Scene
    @IBOutlet weak var metreTextbox: UITextField!
    @IBOutlet weak var kmTextbox: UITextField!
    @IBOutlet weak var mileTextbox: UITextField!
    @IBOutlet weak var cmTextbox: UITextField!
    @IBOutlet weak var mmTextbox: UITextField!
    @IBOutlet weak var yardTextbox: UITextField!
    @IBOutlet weak var inchTextbox: UITextField!
    
    //bool to check if the textfields arez empty before input
    var shouldClearDisplayBeforeInserting = true
    
    //clears the textfields
    @IBAction func clearDisplay() {
        metreTextbox.text = ""
        kmTextbox.text = ""
        mileTextbox.text = ""
        cmTextbox.text = ""
        mmTextbox.text = ""
        yardTextbox.text = ""
        inchTextbox.text = ""
        shouldClearDisplayBeforeInserting = true
    }
    
    //checks if any of the numbers from the calculator have been clicked and inserts the coresponding number into the textfield
    //converts according to the selected field
    /*------------Length Conversions--------------*/
    @IBAction func didTapNumber(number: UIButton) {
        
        if shouldClearDisplayBeforeInserting {
            if(metreTextbox.isEditing) {
                metreTextbox.text = ""
            } else if(kmTextbox.isEditing) {
                kmTextbox.text = ""
            } else if(mileTextbox.isEditing) {
                mileTextbox.text = ""
            } else if(cmTextbox.isEditing) {
                cmTextbox.text = ""
            } else if(mmTextbox.isEditing) {
                mmTextbox.text = ""
            } else if(yardTextbox.isEditing) {
                yardTextbox.text = ""
            } else if(inchTextbox.isEditing) {
                inchTextbox.text = ""
            }
            
            shouldClearDisplayBeforeInserting = false
        }
        
        if let numberAsString = number.titleLabel?.text {
            let numberAsNSString = numberAsString as NSString
            if(metreTextbox.isEditing) {
                if let oldDisplay = metreTextbox?.text! {
                    metreTextbox.text = "\(oldDisplay)\(numberAsNSString.intValue)"
                    let intValue = Double(metreTextbox.text!)
                    let km = intValue! / 1000
                    let mile = intValue! / 1609
                    let cm = intValue! * 100
                    let mm = intValue! * 1000
                    let yard = intValue! * 1.094
                    let inch = intValue! * 39.37
                    
                    kmTextbox.text = String(km)
                    mileTextbox.text = String(mile)
                    cmTextbox.text = String(cm)
                    mmTextbox.text = String(mm)
                    yardTextbox.text = String(yard)
                    inchTextbox.text = String(inch)
                } else {
                    metreTextbox.text = "\(numberAsNSString.intValue)"
                }
            } else if(kmTextbox.isEditing) {
                if let oldDisplay = kmTextbox?.text! {
                    kmTextbox.text = "\(oldDisplay)\(numberAsNSString.intValue)"
                    let intValue = Double(kmTextbox.text!)
                    let metre = intValue! * 1000
                    let mile = intValue! / 1.609
                    let cm = intValue! * 1e+6
                    let mm = intValue! * 1000
                    let yard = intValue! * 1094
                    let inch = intValue! * 39370
                    
                    metreTextbox.text = String(metre)
                    mileTextbox.text = String(mile)
                    cmTextbox.text = String(cm)
                    mmTextbox.text = String(mm)
                    yardTextbox.text = String(yard)
                    inchTextbox.text = String(inch)
                } else {
                    kmTextbox.text = "\(numberAsNSString.intValue)"
                }
            } else if(mileTextbox.isEditing) {
                if let oldDisplay = mileTextbox?.text! {
                    mileTextbox.text = "\(oldDisplay)\(numberAsNSString.intValue)"
                    let intValue = Double(mileTextbox.text!)
                    let metre = intValue! * 1609
                    let km = intValue! * 1.609
                    let cm = intValue! * 160934
                    let mm = intValue! * 1.609e+6
                    let yard = intValue! * 1760
                    let inch = intValue! * 63360
                    
                    metreTextbox.text = String(metre)
                    kmTextbox.text = String(km)
                    cmTextbox.text = String(cm)
                    mmTextbox.text = String(mm)
                    yardTextbox.text = String(yard)
                    inchTextbox.text = String(inch)
                } else {
                    mileTextbox.text = "\(numberAsNSString.intValue)"
                }
            } else if(cmTextbox.isEditing) {
                if let oldDisplay = cmTextbox?.text! {
                    cmTextbox.text = "\(oldDisplay)\(numberAsNSString.intValue)"
                    let intValue = Double(cmTextbox.text!)
                    let metre = intValue! / 100000
                    let km = intValue! / 100
                    let mile = intValue! / 160934
                    let mm = intValue! * 10
                    let yard = intValue! / 91.44
                    let inch = intValue! / 2.54
                    
                    metreTextbox.text = String(metre)
                    kmTextbox.text = String(km)
                    mileTextbox.text = String(mile)
                    mmTextbox.text = String(mm)
                    yardTextbox.text = String(yard)
                    inchTextbox.text = String(inch)
                } else {
                    cmTextbox.text = "\(numberAsNSString.intValue)"
                }
            } else if(mmTextbox.isEditing) {
                if let oldDisplay = mmTextbox?.text! {
                    mmTextbox.text = "\(oldDisplay)\(numberAsNSString.intValue)"
                    let intValue = Double(mmTextbox.text!)
                    let metre = intValue! / 1000
                    let km = intValue! / 1e-6
                    let mile = intValue! * 1e+6
                    let cm = intValue! / 10
                    let yard = intValue! / 914
                    let inch = intValue! / 25.4
                    
                    metreTextbox.text = String(metre)
                    kmTextbox.text = String(km)
                    mileTextbox.text = String(mile)
                    cmTextbox.text = String(cm)
                    yardTextbox.text = String(yard)
                    inchTextbox.text = String(inch)
                } else {
                    mmTextbox.text = "\(numberAsNSString.intValue)"
                }
            } else if(yardTextbox.isEditing) {
                if let oldDisplay = yardTextbox?.text! {
                    yardTextbox.text = "\(oldDisplay)\(numberAsNSString.intValue)"
                    let intValue = Double(yardTextbox.text!)
                    let metre = intValue! / 1.094
                    let km = intValue! / 1094
                    let mile = intValue! / 1760
                    let cm = intValue! * 91.44
                    let mm = intValue! * 914
                    let inch = intValue! * 36
                    
                    metreTextbox.text = String(metre)
                    kmTextbox.text = String(km)
                    mileTextbox.text = String(mile)
                    cmTextbox.text = String(cm)
                    mmTextbox.text = String(mm)
                    inchTextbox.text = String(inch)
                } else {
                    yardTextbox.text = "\(numberAsNSString.intValue)"
                }
            } else if(inchTextbox.isEditing) {
                if let oldDisplay = inchTextbox?.text! {
                    inchTextbox.text = "\(oldDisplay)\(numberAsNSString.intValue)"
                    let intValue = Double(inchTextbox.text!)
                    let metre = intValue! / 39.37
                    let km = intValue! / 39370
                    let mile = intValue! / 63360
                    let cm = intValue! * 2.54
                    let mm = intValue! * 25.4
                    let yard = intValue! / 36
                    
                    metreTextbox.text = String(metre)
                    kmTextbox.text = String(km)
                    mileTextbox.text = String(mile)
                    cmTextbox.text = String(cm)
                    mmTextbox.text = String(mm)
                    yardTextbox.text = String(yard)
                } else {
                    inchTextbox.text = "\(numberAsNSString.intValue)"
                }
            }
        }
    }
    
    //checks if the dot button has been pressed and inserts it into the textfield
    @IBAction func didTapDot() {
        if(metreTextbox.isEditing) {
            if let input = metreTextbox?.text {
                var hasDot = false
                for ch in input.unicodeScalars {
                    if ch == "." {
                        hasDot = true
                        break
                    }
                }
                if hasDot == false {
                    metreTextbox.text = "\(input)."
                }
            }
        } else if(kmTextbox.isEditing) {
            if let input = kmTextbox?.text {
                var hasDot = false
                for ch in input.unicodeScalars {
                    if ch == "." {
                        hasDot = true
                        break
                    }
                }
                if hasDot == false {
                    kmTextbox.text = "\(input)."
                }
            }
        } else if(mileTextbox.isHidden) {
            if let input = mileTextbox?.text {
                var hasDot = false
                for ch in input.unicodeScalars {
                    if ch == "." {
                        hasDot = true
                        break
                    }
                }
                if hasDot == false {
                    mileTextbox.text = "\(input)."
                }
            }
        } else if(cmTextbox.isEditing) {
            if let input = cmTextbox?.text {
                var hasDot = false
                for ch in input.unicodeScalars {
                    if ch == "." {
                        hasDot = true
                        break
                    }
                }
                if hasDot == false {
                    cmTextbox.text = "\(input)."
                }
            }
        } else if(mmTextbox.isEditing) {
            if let input = mmTextbox?.text {
                var hasDot = false
                for ch in input.unicodeScalars {
                    if ch == "." {
                        hasDot = true
                        break
                    }
                }
                if hasDot == false {
                    mmTextbox.text = "\(input)."
                }
            }
        } else if(yardTextbox.isEditing) {
            if let input = yardTextbox?.text {
                var hasDot = false
                for ch in input.unicodeScalars {
                    if ch == "." {
                        hasDot = true
                        break
                    }
                }
                if hasDot == false {
                    yardTextbox.text = "\(input)."
                }
            }
        } else if(inchTextbox.isEditing) {
            if let input = inchTextbox?.text {
                var hasDot = false
                for ch in input.unicodeScalars {
                    if ch == "." {
                        hasDot = true
                        break
                    }
                }
                if hasDot == false {
                    inchTextbox.text = "\(input)."
                }
            }
        }
    }
    
    //saving the length conversions to history
    @IBAction func saveLength(_ sender: Any) {
        lengthDictionary.append(lengths(metre: metreTextbox.text ?? "", cm: cmTextbox.text ?? "", mm: mmTextbox.text ?? "", km: kmTextbox.text ?? "", mile: mileTextbox.text ?? "", yard: yardTextbox.text ?? "", inch: inchTextbox.text ?? ""))
    }
    
}
