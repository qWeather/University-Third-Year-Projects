//
//  TemperatureViewController.swift
//  Unit Converter
//
//  Created by Beatrice Antoniu on 15/03/2021.
//

import UIKit
class TemperatureViewController: UIViewController {
    
    //textfields of Temperature Scene
    @IBOutlet weak var celsiusTextbox: UITextField!
    @IBOutlet weak var fahrenheitTextbox: UITextField!
    @IBOutlet weak var kelvinTextbox: UITextField!
    
    //bool to check if the textfields are empty before input
    var shouldClearDisplayBeforeInserting = true
    
    //clears the textfields
    @IBAction func clearDisplay() {
        celsiusTextbox.text = ""
        kelvinTextbox.text = ""
        fahrenheitTextbox.text = ""
        shouldClearDisplayBeforeInserting = true
    }
    
    //checks if any of the numbers from the calculator have been clicked and inserts the coresponding number into the textfield
    //converts according to the selected field
    /*-----------Temperature Conversions----------*/
    @IBAction func didTapNumber(number: UIButton) {
        
        if shouldClearDisplayBeforeInserting {
            if(celsiusTextbox.isEditing) {
                celsiusTextbox.text = ""
            } else if(fahrenheitTextbox.isEditing) {
                fahrenheitTextbox.text = ""
            } else if(kelvinTextbox.isEditing) {
                kelvinTextbox.text = ""
            }
            
            shouldClearDisplayBeforeInserting = false
        }
        
        if let numberAsString = number.titleLabel?.text {
            let numberAsNSString = numberAsString as NSString
            if(celsiusTextbox.isEditing) {
                if let oldDisplay = celsiusTextbox?.text! {
                    celsiusTextbox.text = "\(oldDisplay)\(numberAsNSString.intValue)"
                    let intValue = Double(celsiusTextbox.text!)
                    let kelvin = intValue! + 273.15
                    let fahrenheit = (intValue! * 9/5) + 32
                    
                    fahrenheitTextbox.text = String(fahrenheit)
                    kelvinTextbox.text = String(kelvin)
                } else {
                    celsiusTextbox.text = "\(numberAsNSString.intValue)"
                }
            } else if(kelvinTextbox.isEditing) {
                if let oldDisplay = kelvinTextbox?.text! {
                    kelvinTextbox.text = "\(oldDisplay)\(numberAsNSString.intValue)"
                    let intValue = Double(kelvinTextbox.text!)
                    let fahrenheit = (intValue! - 273.15) * 9/5 + 32
                    let celsius = intValue! - 273.15
                    
                    fahrenheitTextbox.text = String(fahrenheit)
                    celsiusTextbox.text = String(celsius)
                } else {
                    kelvinTextbox.text = "\(numberAsNSString.intValue)"
                }
            } else if(fahrenheitTextbox.isEditing) {
                if let oldDisplay = fahrenheitTextbox?.text! {
                    fahrenheitTextbox.text = "\(oldDisplay)\(numberAsNSString.intValue)"
                    let intValue = Double(fahrenheitTextbox.text!)
                    let celsius = (intValue! - 32) * 5/9
                    let kelvin = (intValue! - 32) * 5/9 + 273.15
                    
                    celsiusTextbox.text = String(celsius)
                    kelvinTextbox.text = String(kelvin)
                } else {
                    fahrenheitTextbox.text = "\(numberAsNSString.intValue)"
                }
            }
        }
    }
    
    //checks if the dot button has been pressed and inserts it into the label
    @IBAction func didTapDot() {
        if(celsiusTextbox.isEditing) {
            if let input = celsiusTextbox?.text {
                var hasDot = false
                for ch in input.unicodeScalars {
                    if ch == "." {
                        hasDot = true
                        break
                    }
                }
                if hasDot == false {
                    celsiusTextbox.text = "\(input)."
                }
            }
        } else if(fahrenheitTextbox.isEditing) {
            if let input = fahrenheitTextbox?.text {
                var hasDot = false
                for ch in input.unicodeScalars {
                    if ch == "." {
                        hasDot = true
                        break
                    }
                }
                if hasDot == false {
                    fahrenheitTextbox.text = "\(input)."
                }
            }
        } else if(kelvinTextbox.isEditing) {
            if let input = kelvinTextbox?.text {
                var hasDot = false
                for ch in input.unicodeScalars {
                    if ch == "." {
                        hasDot = true
                        break
                    }
                }
                if hasDot == false {
                    kelvinTextbox.text = "\(input)."
                }
            }
        }
    }
    //checks if the negative button has been pressed and inserts it into the textfield only for temperature conversions
    @IBAction func didTapNeg() {
        
        if(celsiusTextbox.isEditing) {
            if let input = celsiusTextbox?.text {
                var hasNeg = false
                for ch in input.unicodeScalars {
                    if ch == "-" {
                        hasNeg = true
                        break
                    }
                }
                if hasNeg == false {
                    celsiusTextbox.text = "-\(input)"
                }
            }
        } else if(fahrenheitTextbox.isEditing) {
            if let input = fahrenheitTextbox?.text {
                var hasNeg = false
                for ch in input.unicodeScalars {
                    if ch == "-" {
                        hasNeg = true
                        break
                    }
                }
                if hasNeg == false {
                    fahrenheitTextbox.text = "-\(input)"
                }
            }
        } else if(kelvinTextbox.isEditing) {
            if let input = kelvinTextbox?.text {
                var hasNeg = false
                for ch in input.unicodeScalars {
                    if ch == "-" {
                        hasNeg = true
                        break
                    }
                }
                if hasNeg == false {
                    kelvinTextbox.text = "-\(input)"
                }
            }
        }
    }
    
    //saving the temperature conversions to history
    @IBAction func saveTemperature(_ sender: Any) {
        temperatureDictionary.append(temperatures(celsius: celsiusTextbox.text ?? "", fahrenheit: fahrenheitTextbox.text ?? "", kelvin: kelvinTextbox.text ?? ""))
        
    }
}
