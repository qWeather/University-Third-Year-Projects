//
//  SpeedViewController.swift
//  Unit Converter
//
//  Created by Beatrice Antoniu on 15/03/2021.
//

import UIKit
class SpeedViewController: UIViewController {
    
    //textfields of Speed Scene
    @IBOutlet weak var msTextbox: UITextField!
    @IBOutlet weak var kmhTextbox: UITextField!
    @IBOutlet weak var mhTextbox: UITextField!
    @IBOutlet weak var knotTextbox: UITextField!
    
    //bool to check if the textfields are empty before input
    var shouldClearDisplayBeforeInserting = true
    
    //clears the textfields
    @IBAction func clearDisplay() {
        msTextbox.text = ""
        kmhTextbox.text = ""
        mhTextbox.text = ""
        knotTextbox.text = ""
        shouldClearDisplayBeforeInserting = true
    }
    
    //checks if any of the numbers from the calculator have been clicked and inserts the coresponding number into the textfield
    //converts according to the selected field
    /*------------Speed Conversions---------------*/
    @IBAction func didTapNumber(number: UIButton) {
        
        if shouldClearDisplayBeforeInserting {
            if(msTextbox.isEditing) {
                msTextbox.text = ""
            } else if(kmhTextbox.isEditing) {
                kmhTextbox.text = ""
            } else if(mhTextbox.isEditing) {
                mhTextbox.text = ""
            } else if(knotTextbox.isEditing) {
                knotTextbox.text = ""
            }
            
            shouldClearDisplayBeforeInserting = false
        }
        
        if let numberAsString = number.titleLabel?.text {
            let numberAsNSString = numberAsString as NSString
            if(msTextbox.isEditing) {
                if let oldDisplay = msTextbox?.text! {
                    msTextbox.text = "\(oldDisplay)\(numberAsNSString.intValue)"
                    let intValue = Double(msTextbox.text!)
                    let kmh = intValue! * 3.6
                    let mh = intValue! * 2.237
                    let knot = intValue! * 1.944
                    
                    kmhTextbox.text = String(kmh)
                    mhTextbox.text = String(mh)
                    knotTextbox.text = String(knot)
                } else {
                    msTextbox.text = "\(numberAsNSString.intValue)"
                }
            } else if(kmhTextbox.isEditing) {
                if let oldDisplay = kmhTextbox?.text! {
                    kmhTextbox.text = "\(oldDisplay)\(numberAsNSString.intValue)"
                    let intValue = Double(kmhTextbox.text!)
                    let ms = intValue! / 3.6
                    let mh = intValue! / 1.609
                    let knot = intValue! / 1.852
                    
                    msTextbox.text = String(ms)
                    mhTextbox.text = String(mh)
                    knotTextbox.text = String(knot)
                } else {
                    kmhTextbox.text = "\(numberAsNSString.intValue)"
                }
            } else if(mhTextbox.isEditing) {
                if let oldDisplay = mhTextbox?.text! {
                    mhTextbox.text = "\(oldDisplay)\(numberAsNSString.intValue)"
                    let intValue = Double(mhTextbox.text!)
                    let ms = intValue! / 2.237
                    let kmh = intValue! * 1.609
                    let knot = intValue! / 1.151
                    
                    msTextbox.text = String(ms)
                    kmhTextbox.text = String(kmh)
                    knotTextbox.text = String(knot)
                } else {
                    mhTextbox.text = "\(numberAsNSString.intValue)"
                }
            } else if(knotTextbox.isEditing) {
                if let oldDisplay = knotTextbox?.text! {
                    knotTextbox.text = "\(oldDisplay)\(numberAsNSString.intValue)"
                    let intValue = Double(knotTextbox.text!)
                    let ms = intValue! / 1.944
                    let kmh = intValue! * 1.852
                    let mh = intValue! * 1.151
                    
                    msTextbox.text = String(ms)
                    kmhTextbox.text = String(kmh)
                    mhTextbox.text = String(mh)
                } else {
                    knotTextbox.text = "\(numberAsNSString.intValue)"
                }
            }
        }
    }
    
    //checks if the dot button has been pressed and inserts it into the textfield
    @IBAction func didTapDot() {
        if(msTextbox.isEditing) {
            if let input = msTextbox?.text {
                var hasDot = false
                for ch in input.unicodeScalars {
                    if ch == "." {
                        hasDot = true
                        break
                    }
                }
                if hasDot == false {
                    msTextbox.text = "\(input)."
                }
            }
        } else if(kmhTextbox.isEditing) {
            if let input = kmhTextbox?.text {
                var hasDot = false
                for ch in input.unicodeScalars {
                    if ch == "." {
                        hasDot = true
                        break
                    }
                }
                if hasDot == false {
                    kmhTextbox.text = "\(input)."
                }
            }
        } else if(mhTextbox.isHidden) {
            if let input = mhTextbox?.text {
                var hasDot = false
                for ch in input.unicodeScalars {
                    if ch == "." {
                        hasDot = true
                        break
                    }
                }
                if hasDot == false {
                    mhTextbox.text = "\(input)."
                }
            }
        } else if(knotTextbox.isEditing) {
            if let input = knotTextbox?.text {
                var hasDot = false
                for ch in input.unicodeScalars {
                    if ch == "." {
                        hasDot = true
                        break
                    }
                }
                if hasDot == false {
                    knotTextbox.text = "\(input)."
                }
            }
        }
    }
    
    //saving the speed conversions to history
    @IBAction func saveSpeed(_ sender: Any) {
        speedDictionary.append(speeds(ms: msTextbox.text ?? "", kmh: kmhTextbox.text ?? "", mh: mhTextbox.text ?? "", knot: knotTextbox.text ?? ""))
    }
}
