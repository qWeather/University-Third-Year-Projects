//
//  UtilitiesController.swift
//  Unit Converter
//
//  Created by Beatrice Antoniu on 15/03/2021.
//

import Foundation

/*----structure for mass measurements-----*/
struct weights {
    var kilogram: String
    var gram: String
    var ounce: String
    var pound: String
    var stonePound: String
}

/*----structure for temperature measurements-----*/
struct temperatures {
    var celsius: String
    var fahrenheit: String
    var kelvin: String
}

/*----structure for length measurements-----*/
struct lengths {
    var metre: String
    var cm: String
    var mm: String
    var km: String
    var mile: String
    var yard: String
    var inch: String
}

/*----structure for speed measurements-----*/
struct speeds {
    var ms: String
    var kmh: String
    var mh: String
    var knot: String
}

/*----structure for volume measurements-----*/
struct volumes {
    var ukGallon: String
    var ukPint: String
    var litre: String
    var fluidOunce: String
    var millilitre: String
}

/*----Dictionaries for history display------*/
var weightDictionary = [weights]()
var temperatureDictionary = [temperatures]()
var lengthDictionary = [lengths]()
var speedDictionary = [speeds]()
var volumeDictionary = [volumes]()
