//
//  VolumeViewController.swift
//  Unit Converter
//
//  Created by Beatrice Antoniu on 15/03/2021.
//

import UIKit
class VolumeViewController:UIViewController {
    
    //textfields of Volume Scene
    @IBOutlet weak var ukGallonTextbox: UITextField!
    @IBOutlet weak var litreTextbox: UITextField!
    @IBOutlet weak var ukPintTextbox: UITextField!
    @IBOutlet weak var fluidOunceTextbox: UITextField!
    @IBOutlet weak var millilitreTextbox: UITextField!
    
    //bool to check if the textfields are empty before input
    var shouldClearDisplayBeforeInserting = true
    
    //clears the textfields
    @IBAction func clearDisplay() {
        ukGallonTextbox.text = ""
        litreTextbox.text = ""
        ukPintTextbox.text = ""
        fluidOunceTextbox.text = ""
        millilitreTextbox.text = ""
        shouldClearDisplayBeforeInserting = true
    }
    
    //checks if any of the numbers from the calculator have been clicked and inserts the coresponding number into the textfield
    //converts according to the selected field
    /*------------Volume Conversions--------------*/
    @IBAction func didTapNumber(number: UIButton) {
        
        if shouldClearDisplayBeforeInserting {
            if(ukGallonTextbox.isEditing) {
                ukGallonTextbox.text = ""
            } else if(litreTextbox.isEditing) {
                litreTextbox.text = ""
            } else if(ukPintTextbox.isEditing) {
                ukPintTextbox.text = ""
            } else if(fluidOunceTextbox.isEditing) {
                fluidOunceTextbox.text = ""
            } else if(millilitreTextbox.isEditing) {
                millilitreTextbox.text = ""
            }
            
            shouldClearDisplayBeforeInserting = false
        }
        
        if let numberAsString = number.titleLabel?.text {
            let numberAsNSString = numberAsString as NSString
            if(ukGallonTextbox.isEditing) {
                if let oldDisplay = ukGallonTextbox?.text! {
                    ukGallonTextbox.text = "\(oldDisplay)\(numberAsNSString.intValue)"
                    let intValue = Double(ukGallonTextbox.text!)
                    let litre = intValue! * 4.546
                    let ukPint = intValue! * 8
                    let fluidOunce = intValue! * 154
                    let millilitre = intValue! * 4546
                    
                    litreTextbox.text = String(litre)
                    ukPintTextbox.text = String(ukPint)
                    fluidOunceTextbox.text = String(fluidOunce)
                    millilitreTextbox.text = String(millilitre)
                } else {
                    ukGallonTextbox.text = "\(numberAsNSString.intValue)"
                }
            } else if(ukPintTextbox.isEditing) {
                if let oldDisplay = ukPintTextbox?.text! {
                    ukPintTextbox.text = "\(oldDisplay)\(numberAsNSString.intValue)"
                    let intValue = Double(ukPintTextbox.text!)
                    let ukGallon = intValue! / 8
                    let litre = intValue! / 1.76
                    let fluidOunce = intValue! * 19.215
                    let millilitre = intValue! * 568
                    
                    ukGallonTextbox.text = String(ukGallon)
                    litreTextbox.text = String(litre)
                    fluidOunceTextbox.text = String(fluidOunce)
                    millilitreTextbox.text = String(millilitre)
                } else {
                    ukPintTextbox.text = "\(numberAsNSString.intValue)"
                }
            } else if(fluidOunceTextbox.isEditing) {
                if let oldDisplay = fluidOunceTextbox?.text! {
                    fluidOunceTextbox.text = "\(oldDisplay)\(numberAsNSString.intValue)"
                    let intValue = Double(fluidOunceTextbox.text!)
                    let ukGallon = intValue! / 160
                    let litre = intValue! / 35.195
                    let ukPint = intValue! / 20
                    let millilitre = intValue! * 28.413
                    
                    ukGallonTextbox.text = String(ukGallon)
                    litreTextbox.text = String(litre)
                    ukPintTextbox.text = String(ukPint)
                    millilitreTextbox.text = String(millilitre)
                } else {
                    fluidOunceTextbox.text = "\(numberAsNSString.intValue)"
                }
            } else if(litreTextbox.isEditing) {
                if let oldDisplay = litreTextbox?.text! {
                    litreTextbox.text = "\(oldDisplay)\(numberAsNSString.intValue)"
                    let intValue = Double(litreTextbox.text!)
                    let ukGallon = intValue! / 4.546
                    let ukPint = intValue! * 1.76
                    let fluidOunce = intValue! * 33.814
                    let millilitre = intValue! * 1000
                    
                    ukGallonTextbox.text = String(ukGallon)
                    ukPintTextbox.text = String(ukPint)
                    fluidOunceTextbox.text = String(fluidOunce)
                    millilitreTextbox.text = String(millilitre)
                } else {
                    litreTextbox.text = "\(numberAsNSString.intValue)"
                }
            } else if(millilitreTextbox.isEditing) {
                if let oldDisplay = millilitreTextbox?.text! {
                    millilitreTextbox.text = "\(oldDisplay)\(numberAsNSString.intValue)"
                    let intValue = Double(millilitreTextbox.text!)
                    let ukGallon = intValue! / 4546
                    let litre = intValue! / 1000
                    let fluidOunce = intValue! * 29.574
                    let ukPint = intValue! / 568
                    
                    ukGallonTextbox.text = String(ukGallon)
                    litreTextbox.text = String(litre)
                    fluidOunceTextbox.text = String(fluidOunce)
                    ukPintTextbox.text = String(ukPint)
                } else {
                    millilitreTextbox.text = "\(numberAsNSString.intValue)"
                }
            }
        }
    }
    
    //checks if the dot button has been pressed and inserts it into the textfield
    @IBAction func didTapDot() {
        if(ukGallonTextbox.isEditing) {
            if let input = ukGallonTextbox?.text {
                var hasDot = false
                for ch in input.unicodeScalars {
                    if ch == "." {
                        hasDot = true
                        break
                    }
                }
                if hasDot == false {
                    ukGallonTextbox.text = "\(input)."
                }
            }
        } else if(ukPintTextbox.isEditing) {
            if let input = ukPintTextbox?.text {
                var hasDot = false
                for ch in input.unicodeScalars {
                    if ch == "." {
                        hasDot = true
                        break
                    }
                }
                if hasDot == false {
                    ukPintTextbox.text = "\(input)."
                }
            }
        } else if(litreTextbox.isHidden) {
            if let input = litreTextbox?.text {
                var hasDot = false
                for ch in input.unicodeScalars {
                    if ch == "." {
                        hasDot = true
                        break
                    }
                }
                if hasDot == false {
                    litreTextbox.text = "\(input)."
                }
            }
        } else if(fluidOunceTextbox.isEditing) {
            if let input = fluidOunceTextbox?.text {
                var hasDot = false
                for ch in input.unicodeScalars {
                    if ch == "." {
                        hasDot = true
                        break
                    }
                }
                if hasDot == false {
                    fluidOunceTextbox.text = "\(input)."
                }
            }
        } else if(millilitreTextbox.isEditing) {
            if let input = millilitreTextbox?.text {
                var hasDot = false
                for ch in input.unicodeScalars {
                    if ch == "." {
                        hasDot = true
                        break
                    }
                }
                if hasDot == false {
                    millilitreTextbox.text = "\(input)."
                }
            }
        }
    }
    
    //saving the volume conversions to history
    @IBAction func saveVolume(_ sender: Any) {
        volumeDictionary.append(volumes(ukGallon: ukGallonTextbox.text ?? "", ukPint: ukPintTextbox.text ?? "", litre: litreTextbox.text ?? "", fluidOunce: fluidOunceTextbox.text ?? "", millilitre: millilitreTextbox.text ?? ""))
    }
}
