//
//  WeightViewController.swift
//  Unit Converter
//
//  Created by Beatrice Antoniu on 15/03/2021.
//

import UIKit
class WeightViewController: UIViewController{
    
    //textfields of Weight Scene
    @IBOutlet weak var kgTextbox: UITextField!
    @IBOutlet weak var gramsTextbox: UITextField!
    @IBOutlet weak var ouncesTextbox: UITextField!
    @IBOutlet weak var poundsTextbox: UITextField!
    @IBOutlet weak var stonePoundsTextbox: UITextField!
    
    //bool to check if the textfields are empty before input
    var shouldClearDisplayBeforeInserting = true
    
    //clears the textfields
    @IBAction func clearDisplay() {
        kgTextbox.text = ""
        gramsTextbox.text = ""
        ouncesTextbox.text = ""
        poundsTextbox.text = ""
        stonePoundsTextbox.text = ""
        shouldClearDisplayBeforeInserting = true
    }
    
    //checks if any of the numbers from the calculator have been clicked and inserts the coresponding number into the textfield
    //converts according to the selected field
    /*------------Mass Conversions----------------*/
    @IBAction func didTapNumber(number: UIButton) {
        
        if shouldClearDisplayBeforeInserting {
            if(kgTextbox.isEditing) {
                kgTextbox.text = ""
            } else if(ouncesTextbox.isEditing) {
                ouncesTextbox.text = ""
            } else if(gramsTextbox.isEditing) {
                gramsTextbox.text = ""
            } else if(poundsTextbox.isEditing) {
                poundsTextbox.text = ""
            } else if(stonePoundsTextbox.isEditing) {
                stonePoundsTextbox.text = ""
            }
            
            shouldClearDisplayBeforeInserting = false
        }
        
        if let numberAsString = number.titleLabel?.text {
            let numberAsNSString = numberAsString as NSString
            if(kgTextbox.isEditing) {
                if let oldDisplay = kgTextbox?.text! {
                    kgTextbox.text = "\(oldDisplay)\(numberAsNSString.intValue)"
                    let intValue = Double(kgTextbox.text!)
                    let grams = intValue! * 1000
                    let ounces = intValue! * 35.274
                    let pounds = intValue! * 2.205
                    let stonePounds = intValue! / 6.35
                    
                    gramsTextbox.text = String(grams)
                    ouncesTextbox.text = String(ounces)
                    poundsTextbox.text = String(pounds)
                    stonePoundsTextbox.text = String(stonePounds)
                } else {
                    kgTextbox.text = "\(numberAsNSString.intValue)"
                }
            } else if(gramsTextbox.isEditing) {
                if let oldDisplay = gramsTextbox?.text! {
                    gramsTextbox.text = "\(oldDisplay)\(numberAsNSString.intValue)"
                    let intValue = Double(gramsTextbox.text!)
                    let kg = intValue! / 1000
                    let ounces = intValue! / 28.35
                    let pounds = intValue! / 454
                    let stonePounds = intValue! / 6350
                    
                    kgTextbox.text = String(kg)
                    ouncesTextbox.text = String(ounces)
                    poundsTextbox.text = String(pounds)
                    stonePoundsTextbox.text = String(stonePounds)
                } else {
                    gramsTextbox.text = "\(numberAsNSString.intValue)"
                }
            } else if(ouncesTextbox.isEditing) {
                if let oldDisplay = ouncesTextbox?.text! {
                    ouncesTextbox.text = "\(oldDisplay)\(numberAsNSString.intValue)"
                    let intValue = Double(ouncesTextbox.text!)
                    let grams = intValue! / 35.274
                    let kg = intValue! * 28.35
                    let pounds = intValue! / 16
                    let stonePounds = intValue! / 224
                    
                    gramsTextbox.text = String(grams)
                    kgTextbox.text = String(kg)
                    poundsTextbox.text = String(pounds)
                    stonePoundsTextbox.text = String(stonePounds)
                } else {
                    ouncesTextbox.text = "\(numberAsNSString.intValue)"
                }
            } else if(poundsTextbox.isEditing) {
                if let oldDisplay = poundsTextbox?.text! {
                    poundsTextbox.text = "\(oldDisplay)\(numberAsNSString.intValue)"
                    let intValue = Double(poundsTextbox.text!)
                    let grams = intValue! * 454
                    let ounces = intValue! * 16
                    let kg = intValue! / 2.205
                    let stonePounds = intValue! / 14
                    
                    gramsTextbox.text = String(grams)
                    ouncesTextbox.text = String(ounces)
                    kgTextbox.text = String(kg)
                    stonePoundsTextbox.text = String(stonePounds)
                } else {
                    poundsTextbox.text = "\(numberAsNSString.intValue)"
                }
            } else if(stonePoundsTextbox.isEditing) {
                if let oldDisplay = stonePoundsTextbox?.text! {
                    stonePoundsTextbox.text = "\(oldDisplay)\(numberAsNSString.intValue)"
                    let intValue = Double(stonePoundsTextbox.text!)
                    let grams = intValue! * 6350
                    let ounces = intValue! * 224
                    let pounds = intValue! * 14
                    let kg = intValue! * 6.35
                    
                    gramsTextbox.text = String(grams)
                    ouncesTextbox.text = String(ounces)
                    poundsTextbox.text = String(pounds)
                    kgTextbox.text = String(kg)
                } else {
                    stonePoundsTextbox.text = "\(numberAsNSString.intValue)"
                }
            }
        }
    }
    
    //checks if the dot button has been pressed and inserts it into the textfield
    @IBAction func didTapDot() {
        if(kgTextbox.isEditing) {
            if let input = kgTextbox?.text {
                var hasDot = false
                for ch in input.unicodeScalars {
                    if ch == "." {
                        hasDot = true
                        break
                    }
                }
                if hasDot == false {
                    kgTextbox.text = "\(input)."
                }
            }
        } else if(gramsTextbox.isEditing) {
            if let input = gramsTextbox?.text {
                var hasDot = false
                for ch in input.unicodeScalars {
                    if ch == "." {
                        hasDot = true
                        break
                    }
                }
                if hasDot == false {
                    gramsTextbox.text = "\(input)."
                }
            }
        } else if(ouncesTextbox.isHidden) {
            if let input = ouncesTextbox?.text {
                var hasDot = false
                for ch in input.unicodeScalars {
                    if ch == "." {
                        hasDot = true
                        break
                    }
                }
                if hasDot == false {
                    ouncesTextbox.text = "\(input)."
                }
            }
        } else if(poundsTextbox.isEditing) {
            if let input = poundsTextbox?.text {
                var hasDot = false
                for ch in input.unicodeScalars {
                    if ch == "." {
                        hasDot = true
                        break
                    }
                }
                if hasDot == false {
                    poundsTextbox.text = "\(input)."
                }
            }
        } else if(stonePoundsTextbox.isEditing) {
            if let input = stonePoundsTextbox?.text {
                var hasDot = false
                for ch in input.unicodeScalars {
                    if ch == "." {
                        hasDot = true
                        break
                    }
                }
                if hasDot == false {
                    stonePoundsTextbox.text = "\(input)."
                }
            }
        }
    }
    
    //saving the mass conversions to history
    @IBAction func saveWeight(_ sender: Any) {
        weightDictionary.append(weights(kilogram: kgTextbox.text ?? "", gram: gramsTextbox.text ?? "", ounce: ouncesTextbox.text ?? "", pound: poundsTextbox.text ?? "", stonePound: stonePoundsTextbox.text ?? ""))
    }
    
}
