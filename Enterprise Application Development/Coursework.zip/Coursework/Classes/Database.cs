﻿using MySql.Data.MySqlClient;
using System.Data;

namespace Coursework
{
    class Database
    {
        public MySqlConnection connection;
        public Database()
        {
            string connectionString = "Server=eu-cdbr-west-03.cleardb.net;Database=heroku_4b09cb98cebc824;Uid=babddba9a2ad38;Pwd=954f3524";
            connection = new MySqlConnection(connectionString);

        }

        public void OpenConnection()
        {
            if (connection.State == ConnectionState.Closed)
            {
                connection.Open();
            }

        }

        public void CloseConnection()
        {
            if (connection.State == ConnectionState.Open)
            {
                connection.Close();
            }
        }

        public void CreateAccountToDatabase(string registerUsername, string registerPassword, string registerEmail, string questionSelected, string questionAnswer)
        {
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "INSERT INTO register (username, password, email, question, answer)"
                    + " VALUES ('" + registerUsername + "', '" + registerPassword + "', '" + registerEmail + "', '" + questionSelected + "', '" + questionAnswer + "')";
            cmd.Connection = connection;

            OpenConnection();
            cmd.ExecuteNonQuery();
            CloseConnection();
        }

        public void AddContact(string contactUsername, string contactEmail)
        {
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "INSERT INTO contacts (name, email)" + "VALUES ('" + contactUsername + "', '" + contactEmail + "')";
            cmd.Connection = connection;

            OpenConnection();
            cmd.ExecuteNonQuery();
            CloseConnection();
        }

        public void AddTransaction(string name, string date, string payment)
        {
            MySqlCommand cmd = new MySqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "INSERT INTO transactions (name, date, payment)" + "VALUES ('" + name + "', '" + date + "', '" + payment + "')";
            cmd.Connection = connection;

            OpenConnection();
            cmd.ExecuteNonQuery();
            CloseConnection();
        }
    }
}

