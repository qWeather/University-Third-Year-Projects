﻿using Microsoft.VisualBasic;
using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;

namespace Coursework.Designs.App
{
    /// <summary>
    /// Interaction logic for Contacts.xaml
    /// </summary>
    public partial class Contacts : Page
    {
        Database db = new Database();
        public Contacts()
        {
            InitializeComponent();
            showContacts();
        }

        private void addContact(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            string nameInput = Interaction.InputBox("Add a name:", "Add name");
            string emailInput = Interaction.InputBox("Add an email:", "Add email");
            if (!Regex.IsMatch(emailInput, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase))
            {
                MessageBox.Show("Email not in the right format", "Couldn't add!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                try
                {

                    db.AddContact(nameInput, emailInput);
                    MessageBox.Show("Contact added successfully!", "", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception)
                {
                    MessageBox.Show("Email already exists!");
                }
            }
        }

        private void removeContact(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            string emailFind = Interaction.InputBox("Enter the email:", "Deleting Contact");
            bool flag = false;
            db.OpenConnection();
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM contacts", db.connection);
            MySqlDataReader rd;
            rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                if (rd[1].ToString().Equals(emailFind))
                {
                    flag = true;
                    break;
                }
            }

            rd.Close();

            if (flag == true)
            {

                MySqlCommand cmd2 = new MySqlCommand("DELETE FROM contacts WHERE email= '" + emailFind + "'", db.connection);
                cmd2.ExecuteNonQuery();
                db.CloseConnection();
                MessageBox.Show("Contact removed successfully!", "", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("Contact doesn't exist!");
            }
        }

        private void showContacts()
        {
            MySqlDataAdapter da = new MySqlDataAdapter("SELECT * FROM contacts", db.connection);
            DataSet ds = new DataSet();
            da.Fill(ds, "contacts");
            view.ItemsSource = ds.Tables["contacts"].DefaultView;
        }

        private void updateContacts(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            MySqlDataAdapter da = new MySqlDataAdapter("SELECT * FROM contacts", db.connection);
            DataSet ds = new DataSet();
            da.Fill(ds, "contacts");
            view.ItemsSource = ds.Tables["contacts"].DefaultView;
        }
    }

}
