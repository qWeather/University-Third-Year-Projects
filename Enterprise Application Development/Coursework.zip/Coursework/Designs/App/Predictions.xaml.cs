﻿using MySql.Data.MySqlClient;
using System;
using System.Windows.Controls;

namespace Coursework.Designs.App
{
    /// <summary>
    /// Interaction logic for Predictions.xaml
    /// </summary>
    public partial class Predictions : Page
    {
        Database db = new Database();
        public bool flag = false;
        public Predictions()
        {
            InitializeComponent();
        }

        private void createPrediction(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            float totalExpenses = 0;
            string formattedDateFrom = "";
            string formattedDateTo = "";
            DateTime? selectedDateFrom = datePicker2.SelectedDate;
            DateTime? selectedDateTo = datePicker3.SelectedDate;

            string periodCalculation = (datePicker3.SelectedDate - datePicker2.SelectedDate).Value.Days.ToString();
            Console.WriteLine(periodCalculation);
            if (selectedDateFrom.HasValue)
            {
                formattedDateFrom = selectedDateFrom.Value.ToString("yyyy-MM-dd");
            }
            if (selectedDateTo.HasValue)
            {
                formattedDateTo = selectedDateTo.Value.ToString("yyyy-MM-dd");
            }

            db.OpenConnection();
            MySqlCommand cmd = new MySqlCommand("SELECT SUM(payment) FROM transactions WHERE date= '" + formattedDateFrom + "'", db.connection);
            var result = cmd.ExecuteScalar();
            if (result == null)
            {
                expenses.Content = "Expenses: £";
            }
            else
            {
                totalExpenses += float.Parse(result.ToString());
            }

            MySqlCommand cmd2 = new MySqlCommand("SELECT SUM(payment) FROM transactions WHERE date= '" + formattedDateTo + "'", db.connection);
            var result2 = cmd2.ExecuteScalar();
            if (result2 == null)
            {
                expenses.Content = "Expenses: £";
            }
            else
            {
                totalExpenses += float.Parse(result2.ToString());
            }

            db.CloseConnection();

            float year = 365;
            float month = 31;

            float predictionOverYear = year / float.Parse(periodCalculation) * totalExpenses;
            float predictionOverMonths = (month * 6) / float.Parse(periodCalculation) * totalExpenses;

            expenses.Content = "Expenses: £" + totalExpenses.ToString();
            period.Content = "Period: " + periodCalculation + "days";
            predictedExpensesYear.Content = "Predicted Expenses over a year: £" + predictionOverYear.ToString("0.00");
            predictedExpensesMonth.Content = "Predicted Expenses over 6 months: £" + predictionOverMonths.ToString("0.00");

        }
    }
}
