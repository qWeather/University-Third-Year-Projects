﻿using Microsoft.VisualBasic;
using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;

namespace Coursework.Designs.App
{
    /// <summary>
    /// Interaction logic for Transactions.xaml
    /// </summary>
    public partial class Transactions : Page
    {
        Database db = new Database();
        public Transactions()
        {
            InitializeComponent();
            showTransactions();
        }

        private void addTransaction(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {

            string nameInput = Interaction.InputBox("Add a name:", "Add name");
            string payInput = Interaction.InputBox("Add a payment:", "Add email");
            string dateInput = Interaction.InputBox("Add a date:", "Add date");
            if (!Regex.IsMatch(dateInput, @"^(19|20)\d\d[- /.](0[1-9]|1[012])[- /.](0[1-9]|[12][0-9]|3[01])$", RegexOptions.IgnoreCase))
            {
                MessageBox.Show("Date not in the right format!");
            }
            else
            {
                try
                {
                    db.AddTransaction(nameInput, dateInput, payInput);
                    MessageBox.Show("Transaction added successfully!", "", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch
                {
                    MessageBox.Show("Date not in the right format!");
                }
            }
        }

        private void removeTransaction(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            string id = Interaction.InputBox("Enter the transaction ID:", "Deleting Transaction");
            bool flag = false;
            db.OpenConnection();
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM transactions WHERE id= '" + id + "'", db.connection);
            MySqlDataReader rd;
            rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                if (rd[1].ToString().Equals(id))
                {
                    flag = true;
                    break;
                }
            }

            rd.Close();

            if (flag == true)
            {

                MySqlCommand cmd2 = new MySqlCommand("DELETE FROM transactions WHERE id= '" + id + "'", db.connection);
                cmd2.ExecuteNonQuery();
                db.CloseConnection();
                MessageBox.Show("Transaction removed successfully!", "", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("Transaction doesn't exist!");
            }
        }
        private void showTransactions()
        {
            try
            {
                db.OpenConnection();
                MySqlDataAdapter da = new MySqlDataAdapter("SELECT * FROM transactions", db.connection);
                MySqlCommand cmd = new MySqlCommand("SELECT SUM(payment) FROM transactions", db.connection);
                var result = cmd.ExecuteScalar();
                if (result == null)
                {
                    expensesInTotal.Content = "";
                }
                else
                {
                    expensesInTotal.Content = "Expenses: £" + result.ToString();
                }
                DataSet ds = new DataSet();
                da.Fill(ds, "transactions");
                view2.ItemsSource = ds.Tables["transactions"].DefaultView;
                db.CloseConnection();
            }
            catch (Exception)
            {
                MessageBox.Show("Can't display!");
            }
        }

        private void updateTransactions(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            try
            {
                db.OpenConnection();
                MySqlDataAdapter da = new MySqlDataAdapter("SELECT * FROM transactions", db.connection);
                MySqlCommand cmd = new MySqlCommand("SELECT SUM(payment) FROM transactions", db.connection);
                var result = cmd.ExecuteScalar();
                if (result == null)
                {
                    expensesInTotal.Content = "";
                }
                else
                {
                    expensesInTotal.Content = "Expenses: " + result.ToString();
                }
                DataSet ds = new DataSet();
                da.Fill(ds, "transactions");
                view2.ItemsSource = ds.Tables["transactions"].DefaultView;
                db.CloseConnection();
            }
            catch (Exception)
            {
                MessageBox.Show("Can't display!");
            }
        }
    }
}