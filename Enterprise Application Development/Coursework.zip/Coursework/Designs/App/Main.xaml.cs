﻿using System.Windows;

namespace Coursework.Designs.App
{
    /// <summary>
    /// Interaction logic for Main.xaml
    /// </summary>
    public partial class Main : Window
    {
        public Main()
        {
            InitializeComponent();
        }

        private void Transactions(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            frame.Content = new Transactions();
        }

        private void Predictions(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            frame.Content = new Predictions();
        }

        private void Contacts(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            frame.Content = new Contacts();
        }

        private void Reports(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            frame.Content = new Reports();
        }
    }
}
