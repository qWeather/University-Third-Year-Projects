﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Windows.Controls;

namespace Coursework.Designs.App
{
    /// <summary>
    /// Interaction logic for Reports.xaml
    /// </summary>
    public partial class Reports : Page
    {
        Database db = new Database();
        public bool flag = false;
        public Reports()
        {
            InitializeComponent();
        }

        private void produceReport(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            string formattedDate = "";
            DateTime? selectedDate = datePicker.SelectedDate;
            if (selectedDate.HasValue)
            {
                formattedDate = selectedDate.Value.ToString("yyyy-MM-dd");
            }
            db.OpenConnection();
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM transactions WHERE date= '" + formattedDate + "'", db.connection);
            MySqlDataReader rd;
            rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                if (rd[1].ToString().Equals(formattedDate))
                {
                    flag = true;
                    break;
                }
            }

            rd.Close();

            MySqlCommand cmd2 = new MySqlCommand("SELECT SUM(payment) FROM transactions WHERE date= '" + formattedDate + "'", db.connection);
            var result = cmd2.ExecuteScalar();
            if (result == null)
            {
                expensesByDate.Content = "";
            }
            else
            {
                expensesByDate.Content = "Expenses: £" + result.ToString();
            }

            MySqlDataAdapter da = new MySqlDataAdapter("SELECT name,payment FROM transactions WHERE date= '" + formattedDate + "'", db.connection);
            DataSet ds = new DataSet();
            da.Fill(ds, "transactions");
            view3.ItemsSource = ds.Tables["transactions"].DefaultView;
            db.CloseConnection();

        }
    }
}
