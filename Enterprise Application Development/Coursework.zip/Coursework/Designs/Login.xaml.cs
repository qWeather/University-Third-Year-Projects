﻿using System;
using System.Windows;
using System.Windows.Input;
using Coursework.Designs.App;
using Microsoft.VisualBasic;
using MySql.Data.MySqlClient;

namespace Coursework.Designs
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        Database db = new Database();
        public bool flag = false;
        public string username, password, email, question, answer;

        public Login()
        {
            InitializeComponent();
        }

        private void LoginBtn(object sender, RoutedEventArgs e)
        {
            if (userLogin.Text.Equals(""))
            {
                MessageBox.Show("Username field is empty!", "Couldn't login!", MessageBoxButton.OK, MessageBoxImage.Exclamation);
            }
            else if (passLogin.Password.Equals(""))
            {
                MessageBox.Show("Password field is empty!", "Couldn't login!", MessageBoxButton.OK, MessageBoxImage.Exclamation);
            }
            else
            {
                try
                {
                    db.OpenConnection();

                    string query = "SELECT * FROM register WHERE username ='" + userLogin.Text + "' AND password ='" + passLogin.Password + "'";
                    MySqlCommand cmd = new MySqlCommand(query, db.connection);
                    MySqlDataReader row;
                    row = cmd.ExecuteReader();
                    if (row.HasRows)
                    {
                        while (row.Read())
                        {
                            username = row["username"].ToString();
                            password = row["password"].ToString();
                            email = row["email"].ToString();
                            question = row["question"].ToString();
                            answer = row["answer"].ToString();
                        }

                        MessageBox.Show("Logged in succesfully!", "Success!", MessageBoxButton.OK);

                        this.Hide();
                        Main m = new Main();
                        m.Show();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Wrong credentials!", "Couldn't login!", MessageBoxButton.OK);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                db.CloseConnection();
            }
        }

        private void RegisterLink(object sender, MouseButtonEventArgs e)
        {
            this.Hide();
            Register r = new Register();
            r.Show();
            this.Close();
        }

        private void RecoveryLink(object sender, MouseButtonEventArgs e)
        {
            string emailRecovery = Interaction.InputBox("Enter your email:", "Recover Password");
            Console.WriteLine(emailRecovery);
            db.OpenConnection();
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM register WHERE email= '" + emailRecovery + "'", db.connection);
            MySqlDataReader rd;
            rd = cmd.ExecuteReader();
            if (rd.Read())
            {
                rd[1].ToString().Equals(emailRecovery);
                rd.Close();
                MySqlCommand cmd2 = new MySqlCommand("SELECT password FROM register WHERE email= '" + emailRecovery + "'", db.connection);
                var result = cmd2.ExecuteScalar();
                MessageBox.Show("Your password is: " + result.ToString(), "", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("Account doesn't exist!");
            }

            db.CloseConnection();
        }

        private void HoverOn(object sender, MouseEventArgs e)
        {
            Cursor = Cursors.Hand;
        }

        private void HoverOff(object sender, MouseEventArgs e)
        {
            Cursor = Cursors.Arrow;
        }
    }
}
