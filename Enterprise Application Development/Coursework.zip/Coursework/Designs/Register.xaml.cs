﻿using System;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Input;

namespace Coursework.Designs
{
    /// <summary>
    /// Interaction logic for Register.xaml
    /// </summary>
    public partial class Register : Window
    {
        readonly Database db = new Database();
        public Register()
        {
            InitializeComponent();
            questionBox.Items.Add("What is your favourite pet?");
            questionBox.Items.Add("Where were you born?");
            questionBox.Items.Add("Where did your parents meet?");
            questionBox.Items.Add("What school did you go to?");
            questionBox.Items.Add("Who was your best friend growing up?");
        }

        private void CreateAccount(object sender, RoutedEventArgs e)
        {
            if (usernameTextbox.Text.Length <= 8)
            {
                MessageBox.Show("Username is too short!", "Couldn't register!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else if (usernameTextbox.Text.Equals(""))
            {
                MessageBox.Show("Username field is empty!", "Couldn't register!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else if (passwordTextbox.Password.Equals(""))
            {
                MessageBox.Show("Password field is empty!", "Couldn't register!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else if (passwordTextbox.Password.Length <= 8)
            {
                MessageBox.Show("Password is too short!", "Couldn't register!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else if (reenterTextbox.Password.Equals(""))
            {
                MessageBox.Show("Re-enter password field is empty!", "Couldn't register!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else if (!reenterTextbox.Password.Equals(passwordTextbox.Password))
            {
                MessageBox.Show("Passwords don't match!", "Couldn't register!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else if (emailTextbox.Text.Equals(""))
            {
                MessageBox.Show("Email field is empty!", "Couldn't register!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else if (!Regex.IsMatch(emailTextbox.Text, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase))
            {
                MessageBox.Show("Incorrect email format!", "Couldn't register!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else if (answerTextbox.Text.Equals(""))
            {
                MessageBox.Show("Answer field is empty!", "Couldn't register!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else if (questionBox.SelectedItem == null)
            {
                MessageBox.Show("No question has been selected!", "Couldn't register!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                try
                {

                    db.CreateAccountToDatabase(usernameTextbox.Text, passwordTextbox.Password, emailTextbox.Text, questionBox.SelectedItem.ToString(), answerTextbox.Text);
                    MessageBox.Show("Account was created with success! You will be redirected to the Login page.", "", MessageBoxButton.OK, MessageBoxImage.Information);
                    this.Hide();
                    Login rl = new Login();
                    rl.Show();
                    this.Close();

                }
                catch (Exception)
                {
                    MessageBox.Show("Username or Email already exists!");
                }
            }
        }

        private void GoBack(object sender, RoutedEventArgs e)
        {
            this.Hide();
            Login l = new Login();
            l.Show();
            this.Close();
        }
        private void HoverOn(object sender, MouseEventArgs e)
        {
            Cursor = Cursors.Hand;
        }

        private void HoverOff(object sender, MouseEventArgs e)
        {
            Cursor = Cursors.Arrow;
        }
    }
}

